# D&S Coffee and Sweet — Bot

## Fayl tuzilmasi
```
├── mini-app/
│   ├── index.html     ← Vercel ga yuklanadi
│   └── vercel.json
└── bot/
    ├── bot.py
    ├── config.py      ← TOKEN va ID larni shu yerga yozing
    ├── requirements.txt
    └── railway.toml
```

## GitHub ga yuklash tartibi

### 1. mini-app uchun (Vercel)
- GitHub da yangi repo: `ds-coffee-app`
- `mini-app` papkasidagi 2 faylni yuklang: `index.html` + `vercel.json`
- Vercel ga ulab deploy qiling

### 2. bot uchun (Railway)
- GitHub da yangi repo: `ds-coffee-bot`
- `bot` papkasidagi 4 faylni yuklang: `bot.py` + `config.py` + `requirements.txt` + `railway.toml`
- `config.py` ga TOKEN va ADMIN_ID ni yozing
- Railway ga ulab deploy qiling
